import pandas as pd

# Assuming your data is in a file named 'data.csv'
file_path = 'starData3.csv'  # Replace with your file path

# Read the CSV file directly
df = pd.read_csv(file_path)

# Convert the 'Calendar Date' to datetime to preserve full timestamp
df['Calendar Date'] = pd.to_datetime(df['Calendar Date'])

# Extract date part for grouping while keeping original datetime
df['Date'] = df['Calendar Date'].dt.date

# Group by 'Date' (the date part) and calculate the median magnitude for each date
medians = df.groupby('Date')['Magnitude'].median().reset_index(name='MedianMagnitude')

# Merge the original dataframe with medians to calculate the absolute difference
df = df.merge(medians, left_on='Date', right_on='Date')
df['Difference'] = (df['Magnitude'] - df['MedianMagnitude']).abs()

# Sort by datetime and difference, then drop duplicates to keep the entry closest to the median for each day
df_sorted = df.sort_values(['Date', 'Difference', 'Calendar Date'])
result_df = df_sorted.drop_duplicates(subset=['Date'], keep='first').sort_values('Calendar Date')

# Select only the relevant columns for the final output
final_result = result_df[['Calendar Date', 'Magnitude']]

# Write to a CSV file
output_file_path = 'starData5.csv'  # Define the output file path
final_result.to_csv(output_file_path, index=False)

print(f'Data written to {output_file_path}')
